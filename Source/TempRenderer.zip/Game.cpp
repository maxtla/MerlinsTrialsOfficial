#include"Game.h"

Game::Game() {



}

Game::~Game() {



}

void Game::init(HINSTANCE* hInst, HWND* wHandle) {

	//Init Engine
	this->engine.init(wHandle);

	//init camera
	this->cam.initDI(hInst, wHandle);

	//Init level
	this->level.initialize(this->engine.getDevice(), &this->objImporter);

}

void Game::update(float dt) {

	//Read keyboard/mouse input
	this->cam.getInput();

	//Check camera collision on terrain
	//this->terrainCollision();

	//Update camera
	this->cam.update(dt);

	//Update engine
	this->engine.update(&this->cam, this->level.getGeometry());

}

void Game::terrainCollision() {

	//Camera pos
	DirectX::XMVECTOR camPos = this->cam.getPosition();
	DirectX::XMVECTOR ray = { DirectX::XMVectorGetX(camPos), -1000000.0f, DirectX::XMVectorGetZ(camPos) };

	//Terrain Values
	std::vector<Geometry::Vertex> vertices = this->level.getGeometry()->at(0).getVertices();
	std::vector<int> indices = this->level.getGeometry()->at(0).getIndices();

	this->level.getGeometry()->at(0).writeToFile();

	Matrix terrainWorld = this->level.getGeometry()->at(0).getWorld();
	int vertexCount = this->level.getGeometry()->at(0).getVertexCount();
	int rowColCount = sqrt(this->level.getGeometry()->at(0).getVertexCount());

	//Transform origin/ray into terrain local space
	ray = Vector3::Transform(ray, terrainWorld.Invert());
	camPos = Vector3::Transform(camPos, terrainWorld.Invert());

	bool stopSearch = false;
	float dist = 0.0f;
	Vector3 yValue = Vector3(0.0f, 0.0f, 0.0f);

	for (int i = 0; i < indices.size() && !stopSearch; i+=3) {
		
		//Triangle information
		Vector3 v0 = vertices.at(indices.at(i)).pos - 
			 vertices.at(indices.at(i + 1)).pos;

		Vector3 v1 = vertices.at(indices.at(i)).pos -
			vertices.at(indices.at(i + 2)).pos;

		Vector3 v2 = vertices.at(indices.at(i + 1)).pos -
			vertices.at(indices.at(i + 2)).pos;

		if (DirectX::TriangleTests::Intersects(camPos, ray, v0, v1, v2, dist)) {

			//Get average height
			yValue = Vector3::Transform(v0, terrainWorld);
			yValue += Vector3::Transform(v1, terrainWorld);
			yValue += Vector3::Transform(v2, terrainWorld);
			yValue /= 3.0f;

			//Set offset
			yValue.y += 150.0f;
			this->cam.setMoveY(yValue.y);

			stopSearch = true;

		}

	}

}