#ifndef GAME_H
#define GAME_H

#include"Engine.h"
#include"Level.h"
#include"ObjectImporter.h"
#include<DirectXMath.h>

class Game {

private:

	Camera cam;
	Engine engine;
	Level level;
	ObjectImporter objImporter;

	//Private
	void terrainCollision();

public:

	Game();
	~Game();

	void init(HINSTANCE* hInst, HWND* wHandle);
	void update(float dt);

	//Get

	//Set


};

#endif // !GAME_H
