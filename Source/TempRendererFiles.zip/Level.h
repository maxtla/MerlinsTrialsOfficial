#ifndef LEVEL_H
#define LEVEL_H
#include"ObjectImporter.h"
#include"Object.h"
#include<string>

using namespace DirectX::SimpleMath;

class Level
{
public:

	std::vector<Object> sceneObjects;

private:

	ObjectImporter * objImporter;
	std::vector<Mesh> meshes;
	std::string fileName;
	Matrix standardWorld;

	void createObjects(ID3D11Device* device);

public:
	Level();
	~Level();

	bool initialize(ID3D11Device * in_device, ObjectImporter * importer);
	std::vector<Object>* getObjects();
};

#endif // !LEVEL_H
