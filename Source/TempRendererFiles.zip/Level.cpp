#include "Level.h"

Level::Level()
{
	this->fileName = "Obj//CubeTri.obj";
	this->standardWorld = Matrix::Identity;;
	this->standardWorld.CreateScale(Vector3(1000, 1000, 1000));
}

Level::~Level()
{

	this->objImporter = nullptr;
	this->sceneObjects.clear();
	this->fileName.clear();

}

bool Level::initialize(ID3D11Device* in_device, ObjectImporter * importer)
{
	//start up a scene
	this->objImporter = importer;

	bool rValue = false;
	rValue = this->objImporter->importModel(this->fileName, this->meshes);
	if (rValue)
	{
		//hantera object
		this->createObjects(in_device);
	}

	return rValue;
}

std::vector<Object>* Level::getObjects()
{
	return &this->sceneObjects;
}

void Level::createObjects(ID3D11Device* device)
{
	//reserver space for objects, one spot per mesh
	this->sceneObjects.reserve(this->meshes.capacity());

	//create objects and store to vector
	for (UINT32 i = 0; i < this->meshes.size(); i++)
	{
		Object nObject(&this->meshes.at(i), &this->standardWorld, device);
		this->sceneObjects.push_back(nObject);
	}

	//reset meshes vector, no longer needed

}
