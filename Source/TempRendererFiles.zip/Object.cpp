#include "Object.h"

void Object::createBuffers(ID3D11Device* device)
{

	///// Create vertex buffer /////
	D3D11_BUFFER_DESC vBufferDesc;
	memset(&vBufferDesc, 0, sizeof(vBufferDesc));
	vBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	vBufferDesc.ByteWidth = sizeof(Mesh::Vertex) * (this->mesh->vertices.size());
	vBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

	D3D11_SUBRESOURCE_DATA vBufferData;
	vBufferData.pSysMem = this->mesh->vertices.data();

	device->CreateBuffer(&vBufferDesc, &vBufferData, &this->vBuffer);

	///// Create index buffer /////
	D3D11_BUFFER_DESC iBufferDesc;
	memset(&iBufferDesc, 0, sizeof(iBufferDesc));
	iBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	iBufferDesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
	iBufferDesc.ByteWidth = sizeof(unsigned int) * this->mesh->indices.size();
	iBufferDesc.CPUAccessFlags = 0;
	iBufferDesc.MiscFlags = 0;

	D3D11_SUBRESOURCE_DATA iBufferData;
	iBufferData.pSysMem = this->mesh->indices.data();
	iBufferData.SysMemPitch = 0;
	iBufferData.SysMemSlicePitch = 0; 

	device->CreateBuffer(&iBufferDesc, &iBufferData, &this->iBuffer);

}

Object::Object(Mesh* inMesh, Matrix* world, ID3D11Device* inGDevice)
{
	this->mesh = inMesh;
	this->world = *world;
	this->isVisible = false;
	this->isColliding = false;
	this->vBuffer = nullptr;
	this->iBuffer = nullptr;

	this->createBuffers(inGDevice);
	//this->drawInfo = { this->vBuffer, this->iBuffer };

}

Object::~Object()
{	
	vBuffer->Release();
	iBuffer->Release();
}

void Object::operator=(const Object & obj)
{
	this->mesh = obj.mesh;
	this->world = obj.world;
}

void Object::setMesh(Mesh& inMesh)
{
	this->mesh = &inMesh;
}

void Object::setWorldMatrix(const DirectX::XMMATRIX &inWorld)
{
	this->world = inWorld;
}

void Object::setVisibility(const bool &inIsVisible)
{
	this->isVisible = inIsVisible;
}

void Object::setCollision(const bool &inIsColliding)
{
	this->isColliding = inIsColliding;
}

Mesh* Object::getMesh()	const
{
	return this->mesh;
}

Matrix Object::getWorldMatrix()	const
{
	return this->world;
}

ID3D11Buffer * Object::getVBuffer() const
{
	return this->vBuffer;
}

ID3D11Buffer * Object::getIBuffer() const
{
	return this->iBuffer;
}

Object::DrawInformation Object::getDrawInfo()	const
{
	return this->drawInfo;
}

bool Object::getVisibility()	const
{
	return this->isVisible;
}

bool Object::getCollision()	const
{
	return this->isColliding;
}

int Object::getNrOfVertex(void) const{

	return this->mesh->getNrOfVertex();

}
